package goods;

import java.util.Scanner;

public class SubtractStock implements Managable {
	Goods goods[];
	Scanner sc;
	
	SubtractStock(Goods goods[], Scanner sc){
		this.goods = goods;
		this.sc = sc;
	}
	@Override
	public void addGoods() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void displayGoods() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void changeGoods() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void removeGoods() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addStock() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void subtractStock() throws Exception {
		// TODO Auto-generated method stub
		
	}

}
