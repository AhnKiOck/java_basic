package goods;

public interface Managable {
	void addGoods(); 		//상품등록
	void displayGoods(); 	//상품조회
	void changeGoods(); 	//상품변경
	void removeGoods(); 	//상품삭제 필수 사항 
	
	//	추가사항: 입고, 출고
	 void addStock();
	 void subtractStock() throws Exception; 
}
