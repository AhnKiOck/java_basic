package goods;

public class Goods {
	String name, code;
	int price, stock;
	
	Goods(String name, String code, int price, int stock){
		this.name = name;
		this.code = code;
		this.price = price;
		this.stock = stock;
	}
}
